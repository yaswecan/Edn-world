'use strict';
const assert = require('node:assert/strict');
const vm = require('node:vm');
const fs = require('node:fs');
const path = require('node:path');
const runtime = require('../01_ELEVE/assets/runtime.js');
let checks = 0;
const names = [];

function normalize(value, seen) {
  if (value === undefined) return 'undefined';
  if (typeof value === 'number' && !Number.isFinite(value)) return String(value);
  if (typeof value !== 'object' || value === null) return value;
  const visited = seen || new Set();
  if (visited.has(value)) return '[référence circulaire]';
  visited.add(value);
  let result;
  if (Array.isArray(value)) {
    result = [];
    for (let i = 0; i < value.length; i++) result.push(Object.prototype.hasOwnProperty.call(value, i) ? normalize(value[i], visited) : '[case vide]');
  } else {
    result = {};
    Object.keys(value).forEach(key => { result[key] = normalize(value[key], visited); });
  }
  visited.delete(value);
  return result;
}
function check(name, fn) { fn(); checks++; names.push(name); }
function parity(name, code, invoke, args) {
  check(name, () => {
    const logs = [];
    const sandbox = { console: { log: (...values) => logs.push(values.map(value => normalize(value))) }, inputArgs: structuredClone(args || []) };
    vm.createContext(sandbox);
    vm.runInContext(code, sandbox, { timeout: 500 });
    const expected = invoke ? vm.runInContext(invoke + '(...inputArgs)', sandbox, { timeout: 500 }) : undefined;
    const actual = runtime.run(code, { invoke, args: structuredClone(args || []), maxSteps: 10000 });
    assert.equal(actual.error, null, name + ': ' + actual.error);
    assert.deepEqual(normalize(actual.result), normalize(expected), name + ': result');
    assert.deepEqual(actual.logs, logs, name + ': logs');
    assert.doesNotThrow(() => JSON.stringify(actual.trace));
  });
}

parity('for — toutes les valeurs', 'const niveaux = [20, 70, 50]; for (let i = 0; i < niveaux.length; i++) { console.log(i, niveaux[i]); }');
parity('for — tableau vide', 'const valeurs = []; for (let i = 0; i < valeurs.length; i++) { console.log(valeurs[i]); }');
parity('for — <= lit une case hors limites', 'const valeurs = [2, 4]; for (let i = 0; i <= valeurs.length; i++) { console.log(i, valeurs[i]); }');
parity('for — incrément après le corps', 'let i = 0; for (; i < 3; i++) { console.log(i); } console.log(i);');
parity('for — continue applique la mise à jour', 'for(let i=0;i<4;i++){if(i===1){continue;} console.log(i);}');
parity('for — break évite la mise à jour', 'let i=0;for(;i<5;i++){if(i===2){break;}}console.log(i);');
parity('for — compteurs multiples', 'for(let i=0,j=3;i<3;i++,j--){console.log(i,j);}');
parity('for — boucle décroissante', 'const a=[2,5,8];for(let i=a.length-1;i>=0;i--){console.log(a[i]);}');
const compter = 'function compter(niveaux,seuil){let nombre=0;for(let i=0;i<niveaux.length;i++){if(niveaux[i]>=seuil){nombre++;}}return nombre;}';
parity('comptage — seuil inclus', compter, 'compter', [[20,50,80,49,50],50]);
parity('comptage — liste vide', compter, 'compter', [[],50]);
parity('comptage — zéro retenu', compter, 'compter', [[2,3,4],50]);
parity('comptage — arguments différents', compter, 'compter', [[20,50,80,49,50],80]);
const chercher = 'function chercher(niveaux,seuil){let i=0;while(i<niveaux.length && niveaux[i]<seuil){i++;}if(i<niveaux.length){return i;}return -1;}';
parity('while — trouve indice zéro', chercher, 'chercher', [[80,10],50]);
parity('while — trouve dernier indice', chercher, 'chercher', [[10,20,50],50]);
parity('while — introuvable', chercher, 'chercher', [[10,20],50]);
parity('while — tableau vide', chercher, 'chercher', [[],50]);
parity('while — continue n’incrémente pas seul', 'let i=0;while(i<5){i++;if(i===3){continue;}console.log(i);}');
parity('while — arrêt par break', 'let i=0;while(true){if(i===3){break;}console.log(i);i++;}');
parity('fonction — paramètres et arguments', 'function difference(a,b){return a-b;} console.log(difference(8,3));console.log(difference(3,8));');
parity('fonction — return arrête le corps', 'function lire(a){return a[0]; console.log("jamais");} console.log(lire([4,5]));');
parity('fonction — console.log ne renvoie pas la valeur', 'function afficher(x){console.log(x);} console.log(afficher(7));');
parity('fonction — déclaration sans appel', 'function afficher(x){console.log(x);return x;}');
parity('fonction — argument manquant', 'function f(a,b){console.log(a,b);return b;}', 'f', [3]);
parity('fonction — paramètres locaux', 'let seuil=10;function f(seuil){seuil++;return seuil;}console.log(f(50));console.log(seuil);');
parity('fonction — var peut redéclarer un paramètre', 'function f(a){var a;return a;}', 'f', [7]);
parity('fonction — hoisting', 'console.log(double(4));function double(x){return x*2;}');
parity('fonction — composition', 'function compter(a,s){let n=0;for(let i=0;i<a.length;i++){if(a[i]>=s){n++;}}return n;}function premier(a,s){let i=0;while(i<a.length&&a[i]<s){i++;}return i<a.length?i:-1;}function bilan(a,s){return {nombre:compter(a,s),premier:premier(a,s)};}', 'bilan', [[10,50,80],50]);
parity('fonction — expression nommée récursive', 'const fact=function calcul(n){if(n<=1){return 1;}return n*calcul(n-1);};console.log(fact(5));');
parity('fonction — scopes imbriqués', 'function f(x){let n=0;function ajouter(v){n+=v;}x.forEach(ajouter);return n;}', 'f', [[3,4,5]]);
parity('forEach — valeur et indice', 'const a=[7,4,9];function afficher(valeur,indice){console.log(valeur,indice);}a.forEach(afficher);');
parity('forEach — return ne coupe pas le parcours', 'const a=[10,50,80];a.forEach(function(valeur,indice){if(valeur>=50){return indice;}console.log(valeur);});console.log("fin");');
parity('forEach — tous les callbacks après un return', 'let visites=0;[10,50,80].forEach(function(valeur){visites++;if(valeur>=50){return true;}});console.log(visites);');
parity('forEach — résultat undefined', 'function f(a){return a.forEach(function(v){return v*2;});}', 'f', [[1,2,3]]);
parity('forEach — liste vide', 'let n=0;[].forEach(function(){n++;});console.log(n);');
parity('forEach — ignore les cases vides', 'const a=[1,,3];a.forEach(function(v,i){console.log(i,v);});');
parity('forEach — longueur initiale', 'const a=[1,2];a.forEach(function(v,i){console.log(v,i);a.push(9);});console.log(a);');
parity('forEach — modification d’une future case', 'const a=[1,2,3];a.forEach(function(v,i){console.log(v);if(i===0){a[1]=20;}});');
parity('forEach — troisième argument est le tableau', 'const a=[1,2];a.forEach(function(v,i,tableau){console.log(tableau===a,tableau[i]);});');
parity('const — contenu du tableau modifiable', 'const a=[1];a.push(2);console.log(a);');
parity('alias — même tableau', 'const a=[1];const b=a;b[0]=3;console.log(a,b,a===b);');
parity('tableau — pop et push', 'const a=[1,2];console.log(a.pop());console.log(a.push(4,5));console.log(a);');
parity('objets — main(input)', 'function main(input){let n=0;for(let i=0;i<input.niveaux.length;i++){if(input.niveaux[i]>=input.seuil){n++;}}return n;}', 'main', [{niveaux:[5,50,80],seuil:50}]);
parity('objets — propriété abrégée', 'function f(a){const n=a.length;return {n,a};}', 'f', [[2,3]]);
parity('var — hoisting dans une condition', 'console.log(x);if(true){var x=4;}console.log(x);');
parity('let — closure par itération', 'const f=[];for(let i=0;i<3;i++){f.push(function(){return i;});}console.log(f[0](),f[1](),f[2]());');
parity('var — closure partagée', 'const f=[];for(var i=0;i<3;i++){f.push(function(){return i;});}console.log(f[0](),f[1](),f[2]());');
parity('court-circuit — pas de lecture hors limite', 'const a=[];let i=0;console.log(i<a.length && a[i].valeur>0);');
parity('court-circuit — valeur de || et &&', 'console.log(0||5,3&&7,false&&8,true||9);');
parity('préfixe et postfixe', 'let i=2;console.log(i++,i,++i,i--,--i);');
parity('typeof — nom absent', 'console.log(typeof inconnu);');
parity('chaînes — échappements', 'console.log("a\\nb",\'c\\\'d\',"\\u00e9");');
parity('ASI — return suivi d’une nouvelle ligne', 'function f(){return\n5;}console.log(f());');
parity('if/else imbriqués', 'function f(x){if(x>4){if(x>8){return 2;}else{return 1;}}return 0;}', 'f', [5]);
parity('tableau — index et valeur différents', 'const a=[8,3,5];for(let i=0;i<a.length;i++){console.log(i,a[i]);}');

check('trace — évolution fidèle des indices', () => {
  const result=runtime.run('const a=[3,5];for(let i=0;i<a.length;i++){console.log(a[i]);}');
  assert.deepEqual(result.trace.filter(e=>e.kind==='read').map(e=>[e.index,e.value]),[[0,3],[1,5]]);
  assert.deepEqual(result.trace.filter(e=>e.kind==='update').map(e=>e.value),[1,2]);
  assert.deepEqual(result.trace.filter(e=>e.kind==='condition').map(e=>e.value),[true,true,false]);
});
check('trace — arguments vers paramètres', () => {
  const result=runtime.run('function f(valeurs,seuil){return seuil;}console.log(f([1,2],50));');
  const event=result.trace.find(e=>e.kind==='call');
  assert.deepEqual(event.params,['valeurs','seuil']);
  assert.deepEqual(event.args,[[1,2],50]);
  assert.deepEqual(event.bindings,{valeurs:[1,2],seuil:50});
});
check('trace — déclaration sans appel identifiée', () => {
  const result=runtime.run('function f(x){console.log(x);}');
  assert.equal(result.trace.filter(e=>e.kind==='define').length,1);
  assert.equal(result.trace.filter(e=>e.kind==='call').length,0);
  assert.deepEqual(result.logs,[]);
});
check('trace — retour du callback ignoré', () => {
  const result=runtime.run('[1,2,3].forEach(function(x){return x;});');
  assert.equal(result.trace.filter(e=>e.kind==='foreach-next').length,3);
  assert.equal(result.error,null);
});
check('trace — retour implicite conserve le cadre de fonction', () => {
  const result=runtime.run('function afficher(x){console.log(x);}afficher(4);');
  const event=result.trace.find(e=>e.kind==='return'&&e.implicit);
  assert.equal(event.stack.at(-1).name,'afficher');assert.equal(event.variables.x,4);
});
check('trace — affectation conserve la valeur précédente', () => {
  const result=runtime.run('let n=2;n=4;');const event=result.trace.find(e=>e.kind==='assign');
  assert.equal(event.previous,2);assert.equal(event.value,4);
});
check('protection — while sans évolution interrompu', () => {
  const result=runtime.run('let i=0;while(i<3){console.log(i);}',{maxSteps:150});
  assert.match(result.error,/interrompue après 150/);
  assert.equal(result.trace.at(-1).kind,'error');
});
check('protection — for (;;) interrompu', () => {
  assert.match(runtime.run('for(;;){}',{maxSteps:80}).error,/interrompue/);
});
check('protection — limite de trace signalée', () => {
  const result=runtime.run('for(let i=0;i<20;i++){console.log(i);}',{maxTrace:10});
  assert.equal(result.error,null);assert.equal(result.traceTruncated,true);assert.equal(result.trace.length,10);assert.equal(result.trace.at(-1).kind,'done');
});
check('protection — limite de console signalée', () => {
  const result=runtime.run('for(let i=0;i<20;i++){console.log(i);}',{maxLogs:4});
  assert.equal(result.logsTruncated,true);assert.equal(result.logs.length,4);
});
check('erreur — constante réaffectée', () => assert.match(runtime.run('const a=1;a=2;').error,/constante/));
check('erreur — variable locale hors de portée', () => assert.match(runtime.run('for(let i=0;i<2;i++){}console.log(i);').error,/n’est pas défini/));
check('erreur — TDZ', () => assert.match(runtime.run('console.log(x);let x=1;').error,/avant sa déclaration/));
check('erreur — syntaxe fléchée explicitement refusée', () => assert.match(runtime.run('[1].forEach(x=>x);').error,/fléchées/));
check('erreur — break dans callback refusé', () => assert.match(runtime.run('[1].forEach(function(x){break;});').error,/forEach/));
check('erreur — callback déjà appelé', () => assert.match(runtime.run('function f(x){return x;}[1,2].forEach(f());').error,/attend une fonction/));
check('erreur — syntaxe manquante localisée', () => assert.match(runtime.run('let a=1;\nfor(let i=0 i<3;i++){}').error,/Ligne 2/));
check('erreur — accès à une capacité externe', () => assert.match(runtime.run('fetch("https://example.org");').error,/n’est pas défini/));
check('erreur — propriété de prototype refusée', () => assert.match(runtime.run('const a=[];console.log(a.constructor);').error,/propriété spéciale/));
check('erreur — return global refusé', () => assert.match(runtime.run('return 3;').error,/dans une fonction/));
check('erreur — accolade manquante', () => assert.match(runtime.run('function f(){return 2;').error,/accolade/));
check('erreur — fonction inexistante à invoquer', () => assert.match(runtime.run('let x=1;',{invoke:'absente',args:[]}).error,/n’est pas défini/));
check('trace — snapshots indépendants', () => {
  const result=runtime.run('const a=[1];console.log(a);a.push(2);console.log(a);');
  assert.deepEqual(result.logs,[[[1]],[[1,2]]]);
  const first=result.trace.find(e=>e.kind==='output');assert.deepEqual(first.variables.a,[1]);
});
check('trace — référence circulaire sérialisable', () => {
  const result=runtime.run('const a=[];a.push(a);console.log(a);');
  assert.equal(result.error,null);assert.doesNotThrow(()=>JSON.stringify(result.trace));
});
check('exposition — navigateur sans module', () => {
  const sandbox={};vm.runInNewContext(fs.readFileSync(path.join(__dirname,'../01_ELEVE/assets/runtime.js'),'utf8'),sandbox);
  assert.equal(typeof sandbox.ArrayLabRuntime.run,'function');
  assert.equal(sandbox.ArrayLabRuntime.run('function f(x){return x+1;}',{invoke:'f',args:[2]}).result,3);
});

const contentPath=path.join(__dirname,'../07_SOURCES_EDEN/course-author.json');
if(fs.existsSync(contentPath)) {
  const content=JSON.parse(fs.readFileSync(contentPath,'utf8'));
  for(const activity of content.activities)for(const [index,test] of activity.tests.entries()) {
    check('cours — '+activity.id+' — cas '+(index+1),()=>{
      const result=runtime.run(activity.reference,{invoke:activity.invoke,args:structuredClone(test.args)});
      assert.equal(result.error,null);assert.deepEqual(normalize(result.result),normalize(test.expected));
    });
  }
}

console.log(JSON.stringify({passed:checks,failed:0,engineVersion:runtime.version,checks:names},null,2));

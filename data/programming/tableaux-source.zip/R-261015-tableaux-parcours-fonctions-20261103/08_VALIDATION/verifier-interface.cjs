'use strict';
/* Logical smoke test only. Minimal DOM simulator; NOT a browser or visual/accessibility test. */
const fs = require('fs');
const path = require('path');
const vm = require('vm');
const assert = require('assert');
const ROOT = path.resolve(__dirname,'../01_ELEVE');
const records = [];
const decode = s => String(s).replace(/&lt;/g,'<').replace(/&gt;/g,'>').replace(/&quot;/g,'"').replace(/&#39;/g,"'").replace(/&amp;/g,'&');
const escape = s => String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
class Event { constructor(type, opts={}) { this.type=type; Object.assign(this,opts); } preventDefault(){this.defaultPrevented=true;} }
class Node {
 constructor(tag,doc,text=''){this.tagName=tag.toUpperCase();this.ownerDocument=doc;this.parentNode=null;this.childNodes=[];this.attrs={};this.listeners={};this.style={};this._text=text;this._value=null;this.scrollTop=0;this.clientHeight=360;this.selectionStart=0;this.selectionEnd=0;this.files=[];this._disabled=false;this._hidden=false;this._readonly=false;this._checked=false;
 const self=this;this.dataset=new Proxy({}, {get(_,k){return self.attrs['data-'+String(k).replace(/[A-Z]/g,c=>'-'+c.toLowerCase())]},set(_,k,v){self.setAttribute('data-'+String(k).replace(/[A-Z]/g,c=>'-'+c.toLowerCase()),v);return true;}});
 this.classList={contains(c){return self.className.split(/\s+/).includes(c)},add(...cs){self.className=Array.from(new Set([...self.className.split(/\s+/).filter(Boolean),...cs])).join(' ')},remove(...cs){self.className=self.className.split(/\s+/).filter(x=>!cs.includes(x)).join(' ')},toggle(c,force){const add=force===undefined?!this.contains(c):!!force;if(add)this.add(c);else this.remove(c);return add;}};
 }
 get children(){return this.childNodes.filter(n=>n.tagName!=='#TEXT')}
 get className(){return this.attrs.class||''} set className(v){this.attrs.class=String(v)}
 get id(){return this.attrs.id||''} set id(v){this.attrs.id=String(v)}
 get disabled(){return this._disabled||Object.hasOwn(this.attrs,'disabled')} set disabled(v){this._disabled=!!v;if(!v)delete this.attrs.disabled}
 get hidden(){return this._hidden||Object.hasOwn(this.attrs,'hidden')} set hidden(v){this._hidden=!!v;if(!v)delete this.attrs.hidden}
 get readOnly(){return this._readonly||Object.hasOwn(this.attrs,'readonly')} set readOnly(v){this._readonly=!!v;if(!v)delete this.attrs.readonly}
 get checked(){return this._checked||Object.hasOwn(this.attrs,'checked')} set checked(v){this._checked=!!v;if(!v)delete this.attrs.checked}
 get value(){if(this._value!==null)return this._value;if(this.tagName==='SELECT'){const opts=this.querySelectorAll('option');const selected=opts.find(o=>Object.hasOwn(o.attrs,'selected'))||opts[0];return selected?selected.value:'';}return this.attrs.value||''} set value(v){this._value=String(v)}
 get textContent(){return this.tagName==='#TEXT'?this._text:this.childNodes.map(x=>x.textContent).join('')} set textContent(v){this.childNodes=[];const t=new Node('#text',this.ownerDocument,String(v));this.appendChild(t)}
 get innerHTML(){return this.childNodes.map(serialize).join('')} set innerHTML(v){this.childNodes=[];parse(String(v),this,this.ownerDocument)}
 setAttribute(k,v){this.attrs[k]=String(v)} getAttribute(k){return Object.hasOwn(this.attrs,k)?this.attrs[k]:null} removeAttribute(k){delete this.attrs[k]}
 appendChild(n){n.parentNode=this;this.childNodes.push(n);return n} remove(){if(this.parentNode)this.parentNode.childNodes=this.parentNode.childNodes.filter(n=>n!==this);this.parentNode=null}
 addEventListener(type,fn){(this.listeners[type]||(this.listeners[type]=[])).push(fn)}
 dispatchEvent(event){event.target=this;event.currentTarget=this;const fn=this['on'+event.type];if(fn)fn.call(this,event);for(const f of this.listeners[event.type]||[])f.call(this,event);return true}
 click(){if(this.disabled)return;if(this.tagName==='A'&&this.download)this.ownerDocument.downloads.push({name:this.download,url:this.href});this.dispatchEvent(new Event('click'))}
 focus(){this.ownerDocument.activeElement=this} showModal(){this.open=true} close(){this.open=false}
 setRangeText(s,start,end){this.value=this.value.slice(0,start)+s+this.value.slice(end);this.selectionStart=this.selectionEnd=start+s.length}
 querySelectorAll(selector){const chunks=selector.trim().split(/\s+(?![^\[]*\])/);const out=[];const walk=n=>{for(const child of n.children){if(matchesChain(child,chunks))out.push(child);walk(child)}};walk(this);return out}
 querySelector(selector){return this.querySelectorAll(selector)[0]||null}
}
function matchesChain(n,parts){if(!matches(n,parts.at(-1)))return false;let p=n.parentNode;for(let i=parts.length-2;i>=0;i--){while(p&&!matches(p,parts[i]))p=p.parentNode;if(!p)return false;p=p.parentNode}return true}
function matches(n,s){const tag=s.match(/^[a-zA-Z][\w-]*/);if(tag&&n.tagName!==tag[0].toUpperCase())return false;for(const m of s.matchAll(/#([\w-]+)/g))if(n.id!==m[1])return false;for(const m of s.matchAll(/\.([\w-]+)/g))if(!n.classList.contains(m[1]))return false;for(const m of s.matchAll(/\[([^=\]\s]+)(?:\s*=\s*["']?([^\]"']*)["']?)?\]/g)){if(!Object.hasOwn(n.attrs,m[1]))return false;if(m[2]!==undefined&&n.attrs[m[1]]!==m[2])return false;}return true}
function serialize(n){if(n.tagName==='#TEXT')return escape(n._text);return '<'+n.tagName.toLowerCase()+Object.entries(n.attrs).map(([k,v])=>' '+k+'="'+escape(v)+'"').join('')+'>'+n.innerHTML+'</'+n.tagName.toLowerCase()+'>'}
function parse(html,parent,doc){const stack=[parent],voids=new Set(['META','LINK','INPUT','BR','HR','IMG','SOURCE','WBR']);let i=0;
 while(i<html.length){if(html[i]!=='<'){let j=html.indexOf('<',i);if(j<0)j=html.length;stack.at(-1).appendChild(new Node('#text',doc,decode(html.slice(i,j))));i=j;continue;}
 let j=i+1,quote=null;for(;j<html.length;j++){const c=html[j];if(quote){if(c===quote)quote=null}else if(c==='"'||c==="'")quote=c;else if(c==='>')break;}const token=html.slice(i+1,j);i=j+1;if(/^!|^\?/.test(token))continue;const close=token.match(/^\/([\w:-]+)/);if(close){const tag=close[1].toUpperCase();for(let k=stack.length-1;k>0;k--)if(stack[k].tagName===tag){stack.length=k;break;}continue;}
 const m=token.match(/^([\w:-]+)([\s\S]*)$/);if(!m)continue;const n=new Node(m[1],doc);for(const a of m[2].matchAll(/([^\s=\/]+)(?:\s*=\s*(?:"([^"]*)"|'([^']*)'|([^\s>]+)))?/g))n.setAttribute(a[1],decode(a[2]??a[3]??a[4]??''));stack.at(-1).appendChild(n);if(!voids.has(n.tagName)&&!token.endsWith('/'))stack.push(n);
 }
}
class Document extends Node {constructor(html){super('#document',null);this.ownerDocument=this;this.downloads=[];this.hidden=false;parse(html,this,this);this.body=this.querySelector('body');}createElement(tag){return new Node(tag,this)} }
const course=JSON.parse(fs.readFileSync(path.join(__dirname,'../07_SOURCES_EDEN/course-author.json'),'utf8'));
const document=new Document(fs.readFileSync(path.join(ROOT,'index.html'),'utf8'));
const storage=new Map(),blobs=new Map(),timers=new Map();let timerID=0,urlID=0;
class Blob {constructor(parts,options){this.source=parts.join('');this.type=options?.type||''}async text(){return this.source}}
const context={document,console,Event,Blob,JSON,Date,Math,Number,String,Object,Array,Map,Set,RegExp,Error,TypeError,Boolean,Infinity,NaN,undefined,structuredClone,
 matchMedia:()=>({matches:false}),confirm:()=>true,
 localStorage:{getItem:k=>storage.get(k)||null,setItem:(k,v)=>storage.set(k,String(v)),removeItem:k=>storage.delete(k)},
 URL:{createObjectURL:b=>{const u='blob:mock-'+(++urlID);blobs.set(u,b);return u},revokeObjectURL:()=>{}},
 setTimeout:fn=>{const id=++timerID;timers.set(id,fn);return id},clearTimeout:id=>timers.delete(id),
 setInterval:fn=>{const id=++timerID;timers.set(id,fn);return id},clearInterval:id=>timers.delete(id),
 addEventListener:()=>{},ARRAY_COURSE:course};context.window=context;context.globalThis=context;
vm.createContext(context);vm.runInContext(fs.readFileSync(path.join(ROOT,'assets/runtime.js'),'utf8'),context,{filename:'runtime.js'});vm.runInContext(fs.readFileSync(path.join(ROOT,'assets/lesson.js'),'utf8'),context,{filename:'lesson.js'});
const $=s=>{const e=document.querySelector(s);if(!e)throw new Error('Missing DOM target '+s);return e};
const $$=s=>document.querySelectorAll(s);
function check(name,fn){try{fn();records.push({name,status:'pass'})}catch(e){records.push({name,status:'fail',error:e.message})}}
function changeSession(s){$('#session').value=s;$('#session').dispatchEvent(new Event('change'))}
function block(b){$('[data-block="'+b+'"]').click()}
function openActivity(a){changeSession(a.session);block(a.block);$('[data-activity="'+a.id+'"]').click();$('#mode-code').click()}
function type(selector,value){const e=$(selector);e.value=value;e.dispatchEvent(new Event('input'))}
(async()=>{
 check('Boot: five stable navigation blocks',()=>assert.strictEqual($$('.nav-step').length,5));
 for(const s of [1,2])for(const b of [1,2,3,4,5])check('Navigation session '+s+' block '+b,()=>{changeSession(s);block(b);assert($('#page-heading').textContent.includes('SÉANCE '+s));assert.strictEqual($('[data-block="'+b+'"]').getAttribute('aria-current'),'step');assert($('#content').textContent.length>20)});
 for(const a of course.activities){
  check(a.id+': editor, real execution and expected result',()=>{openActivity(a);type('#code',a.reference);type('#call-args',JSON.stringify(a.args));$('#compile').click();assert.strictEqual($('#run-error').textContent,'');assert(/1 \/ [1-9]/.test($('#trace-count').textContent));$('#finish').click();const expected=context.ArrayLabRuntime.run(a.reference,{invoke:a.invoke,args:structuredClone(a.args)}).result;assert($('#return-view').textContent.includes(JSON.stringify(expected)));});
  check(a.id+': all test cases via UI',()=>{$('#tests').click();assert.strictEqual($$('.test-row.pass').length,a.tests.length);assert.strictEqual($$('.test-row.fail').length,0)});
  check(a.id+': rewind and next step',()=>{$('#restart').click();assert.strictEqual($('#next').disabled,false);$('#next').click();assert(/^2 \/ /.test($('#trace-count').textContent))});
 }
 check('Next step is enabled after editing completed execution',()=>{const a=course.activities[1];openActivity(a);type('#code',a.reference);$('#compile').click();$('#finish').click();assert.strictEqual($('#next').disabled,true);type('#code',a.reference+'\n// modification');assert.strictEqual($('#next').disabled,false)});
 check('forEach starter: four console visits and final -1',()=>{const a=course.activities.find(x=>x.id==='a8-retour-callback');openActivity(a);type('#code',a.starter);$('#compile').click();$('#finish').click();const out=$('#console-output').textContent;assert(out.includes('0')&&out.includes('1')&&out.includes('2')&&out.includes('3'));assert($('#return-view').textContent.includes('-1'))});
 check('Reference for search has no callback mechanism',()=>{const a=course.activities.find(x=>x.id==='a8-retour-callback');openActivity(a);type('#code',a.reference);$('#compile').click();$('#next').click();$('#next').click();assert(!$('#mechanism').textContent.includes('Callback'))});
 for(const s of [1,2]){
  check('Session '+s+': cloze answers and feedback',()=>{changeSession(s);block(5);const cl=course.cloze.find(x=>x.session===s);const answers=cl.segments.filter(x=>typeof x==='object');assert.strictEqual($$('[data-blank]').length,answers.length);$$('[data-blank]').forEach((e,i)=>{e.value=answers[i].answer;e.dispatchEvent(new Event('input'))});$('#check-cloze').click();assert.strictEqual($$('.cloze input.valid').length,answers.length);assert($('#cloze-feedback').textContent.includes(answers.length+' / '+answers.length));});
  check('Session '+s+': cloze word bank toggle',()=>{assert.strictEqual($('#word-bank').hidden,true);$('#show-bank').click();assert.strictEqual($('#word-bank').hidden,false);$('#show-bank').click();assert.strictEqual($('#word-bank').hidden,true)});
 }
 const quizSeen=new Set();for(const s of [1,2])for(const b of [1,5]){changeSession(s);block(b);for(const card of $$('[data-quiz]')){const q=course.quizzes.find(x=>x.id===card.dataset.quiz);if(!q)continue;check('QCM '+q.id+': correct response feedback',()=>{card.querySelector('[data-option="'+q.correct+'"]').click();assert(card.querySelector('.quiz-feedback').textContent.includes(q.options[q.correct].feedback));quizSeen.add(q.id)})}}
 openActivity(course.activities.find(a=>a.id==='a6-recherche-while'));
 for(const card of $$('[data-quiz]')){const q=course.quizzes.find(x=>x.id===card.dataset.quiz);if(!q)continue;check('QCM '+q.id+': correct response feedback',()=>{card.querySelector('[data-option="'+q.correct+'"]').click();assert(card.querySelector('.quiz-feedback').textContent.includes(q.options[q.correct].feedback));quizSeen.add(q.id)})}
 check('Twelve QCM are exercised through UI',()=>assert.strictEqual(quizSeen.size,12));
 check('Mission completion leads to recap, not deferred transfer',()=>{openActivity(course.activities.find(a=>a.id==='a9-bilan-flotte'));$('#continue').click();assert($('[data-block="5"]').getAttribute('aria-current')==='step');});
 check('Deferred transfer remains explicitly accessible',()=>{$('#summary-next').click();assert($('#content').textContent.includes('surveiller une serre'));assert($('[data-block="4"]').getAttribute('aria-current')==='step');});
 check('Invalid arguments show an error without executing',()=>{type('#call-args','invalid');$('#compile').click();assert($('#run-error').textContent.includes('arguments'));$('#case-default').click();});
 check('Missing while increment is interrupted by execution limit',()=>{const a=course.activities.find(x=>x.id==='a6-recherche-while');openActivity(a);type('#code',a.starter);$('#compile').click();assert($('#run-error').textContent.length>20);assert(/limite|interrompue|opérations|operations|exécution/i.test($('#run-error').textContent));});

 check('Export work JSON is created and contains ten workspaces',()=>{$('#export-work').click();assert(document.downloads.length>0);const b=blobs.get(document.downloads.at(-1).url);const exported=JSON.parse(b.source);assert.strictEqual(exported.format,'eden-tableaux-work-v1');assert.strictEqual(Object.keys(exported.state.work).length,10);});
 const exported=JSON.parse(blobs.get(document.downloads.at(-1).url).source);exported.state.session=1;exported.state.block=2;exported.state.activity='a1-indices';exported.state.work['a1-indices'].code=course.activities[0].reference+'\n// reprise vérifiée';
 const raw=JSON.stringify(exported);$('#file-work').files=[{size:raw.length,text:async()=>raw}];await $('#file-work').onchange({target:$('#file-work')});
 check('Import work restores code and clears previous test status',()=>{assert($('#code').value.includes('// reprise vérifiée'));const saved=JSON.parse(storage.get('eden-tableaux-v1'));assert.strictEqual(saved.work['a1-indices'].passed,false)});
 check('Code remains saved when navigating away and back',()=>{const expected=$('#code').value;block(3);block(2);$('#mode-code').click();assert.strictEqual($('#code').value,expected)});
 check('Reduced motion control updates class and saved setting',()=>{$('#reduce-motion').checked=true;$('#reduce-motion').dispatchEvent(new Event('change'));assert(document.body.classList.contains('reduced-motion'));assert.strictEqual(JSON.parse(storage.get('eden-tableaux-v1')).reduced,true)});
 check('Memo dialog can be opened and closed',()=>{$('#open-memo').click();assert.strictEqual($('#memo-dialog').open,true);$('#close-memo').click();assert.strictEqual($('#memo-dialog').open,false)});
 const report={scope:'UI logic with minimal simulated DOM, NOT browser validation',testedAt:new Date().toISOString(),passed:records.filter(r=>r.status==='pass').length,failed:records.filter(r=>r.status==='fail').length,records};
 fs.writeFileSync(path.join(__dirname,'interface-results.json'),JSON.stringify(report,null,2)+'\n');console.log(JSON.stringify(report,null,2));if(report.failed)process.exitCode=1;
})().catch(e=>{console.error('Harness failure:',e.stack);process.exitCode=2});

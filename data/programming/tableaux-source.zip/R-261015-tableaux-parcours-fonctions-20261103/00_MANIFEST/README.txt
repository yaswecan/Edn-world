TABLEAUX : PARCOURS, RECHERCHE ET DÉCOMPOSITION
Version 2 du 3 novembre 2026 — JavaScript — Tween Teach / Eden School A1

DÉMARRER
1. Décompresser entièrement le ZIP.
2. Ouvrir DEMARRER.html, puis « Ouvrir le cours ».
3. Dans chaque atelier : observer l’exemple, passer à Mon code, prévoir,
   modifier, exécuter et vérifier plusieurs cas.
Le cours fonctionne sans installation et sans dépendance Internet.

DEUX SÉANCES
Deux séances de 3 h, pauses comprises. Cinq repères identiques : réactiver,
découvrir/essayer, s’entraîner, réaliser, retenir. Un parcours condensé est
décrit dans le guide si les fonctions sont déjà acquises.
Le dixième atelier (serre) est un transfert à reprendre à distance.

HABILLAGE BLEU CIEL
Interface claire, cartes blanches, accents bleu ciel, texte bleu sombre.
La même palette habille les schémas, retours de réussite et les trois PDF.
Les indices restent violets et les compteurs ambre pour distinguer les rôles.
Les couleurs suivent la direction demandée par l’utilisateur ; elles ne sont
pas présentées comme des tokens officiels extraits de Tween Teach.

UTILISATION DANS TWEEN TEACH
Le dossier 07_SOURCES_EDEN reprend les noms, la structure et les types observés
dans l’export EDEN fourni. lesson.json, activity-specs.json, teacher-guide.json
et rubric.json sont présents. Le manifeste utilise schemaVersion=2 ; la
séance utilise schemaVersion="1.0". Les chemins et empreintes sont vérifiés.

L’importeur et le dépôt de Tween Teach ne sont pas disponibles ici : aucun
import dans l’application n’est revendiqué. La compatibilité est vérifiée
par comparaison de structure avec l’export, pas par exécution de l’importeur.
La révision 2 conserve l’identifiant portable du paquet précédent. Le statut
reste brouillon. La décision Ajouter/Remplacer appartient à l’importeur et au
professeur ; aucune publication automatique n’est demandée.

L’atelier animé est livré dans 01_ELEVE/index.html, avec tous ses assets, et
dans 01_ELEVE/cours-autonome.html (HTML autonome). Le raccordement de ce rendu
au lecteur natif dépend des fonctions d’import de l’application.
01_ELEVE/cours-integre.html contient le même atelier dans un habillage compact
pour un lecteur HTML autorisé. Il n’a aucune dépendance réseau. Ce fichier
n’est pas automatiquement relié à un composant natif : aucune API, aucun
champ d’import ni aucun composant non vérifié n’a été inventé.
Un lecteur iframe conserve l’isolation des styles. Le collage de scripts dans
un éditeur de texte riche ne constitue pas une intégration du laboratoire.
Les sources JSON conservent les dix blocs, les dix éditeurs, les douze QCM,
les deux rappels de réactivation et les deux bilans à trous. Chaque activité
obligatoire est rattachée au déroulé ; le transfert est volontairement séparé.
Pour rester dans les types observés, les QCM de la source EDEN sont encodés
comme choix de lettre dans FillBlank. L’atelier HTML propose les vrais boutons
de choix avec retours spécifiques. Aucun type de composant natif non observé
n’a été inventé.

SAUVEGARDE ET REMISE
Le code, les prévisions, les réponses et les explications sont conservés dans
le stockage local du navigateur lorsqu’il est disponible. Cela n’envoie rien
au serveur Tween Teach. Exporter mon travail télécharge un JSON réimportable.
Exporter .js télécharge le programme courant. Remettre ces fichiers selon le
canal habituel ; un commit Git reste une action à réaliser dans le dépôt.

PROFESSEUR / ÉLÈVE
Cette archive complète est réservée au professeur. Distribuer 01_ELEVE pour
le parcours autonome. Les corrigés complets et sources auteur sont dans
05_CORRECTION et 07_SOURCES_EDEN. Les QCM et indices côté navigateur sont des
outils d’apprentissage, pas des secrets d’évaluation protégés.

EXÉCUTION ET ANIMATIONS
Le laboratoire interprète réellement le code dans un sous-ensemble explicite
de JavaScript : variables, tableaux, fonctions, conditions, for, while,
forEach, return, break/continue et console.log. Il n’utilise ni eval ni Function.
Les fonctions fléchées, le DOM, les classes et le réseau ne sont pas enseignés
ni exécutés. Les constructions non prises en charge donnent une erreur.
Les limites d’opérations interrompent une boucle non terminée ; cette limite
ne prouve pas à elle seule qu’une boucle est mathématiquement infinie.
La lecture animée, le pas à pas et le retour arrière parcourent une trace
de l’exécution. Après modification du code, il faut réexécuter.

VALIDATION
Lire 00_MANIFEST/validation.json pour les contrôles réellement exécutés.
Les tests du moteur et les 54 cas des corrections sont rejouables avec Node.
Les PDF ont été rendus et inspectés. L’archive ne certifie ni l’import natif
ni la sauvegarde serveur ni une acquisition durable des compétences.

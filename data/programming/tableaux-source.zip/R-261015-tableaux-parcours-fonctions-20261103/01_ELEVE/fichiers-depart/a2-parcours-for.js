function parcourir(batteries) {
  const copie = [];
  for (let i = 1; i < batteries.length; i++) {
    copie.push(batteries[i]);
  }
  return copie;
}

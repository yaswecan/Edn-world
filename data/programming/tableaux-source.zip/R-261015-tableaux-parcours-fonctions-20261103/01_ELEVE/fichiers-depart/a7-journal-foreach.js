function journalBatteries(batteries) {
  const journal = [];
  batteries.forEach(function(indice, batterie) {
    journal.push("Drone " + indice + " : " + batterie + "%");
  });
  return journal;
}

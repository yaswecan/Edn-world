function tailleEtValeur(batteries, indice) {
  return [batteries.length, indice];
}

function premierPret(batteries, seuil) {
  let i = 0;
  while (i < batteries.length) {
    if (batteries[i] >= seuil) {
      return i;
    }
    // Fais progresser la recherche.
  }
  return -1;
}

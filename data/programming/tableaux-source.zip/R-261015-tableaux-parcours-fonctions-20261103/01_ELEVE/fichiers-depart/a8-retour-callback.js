function premierPret(batteries, seuil) {
  batteries.forEach(function(batterie, indice) {
    console.log("Case visitée", indice);
    if (batterie >= seuil) {
      return indice;
    }
  });
  return -1;
}

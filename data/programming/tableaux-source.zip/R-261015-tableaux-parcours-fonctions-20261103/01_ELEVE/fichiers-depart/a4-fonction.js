function compterPrets(batteries, seuil) {
  let nombre = 0;
  for (let i = 0; i < batteries.length; i++) {
    if (batteries[i] >= 50) {
      nombre++;
    }
  }
  console.log(nombre);
}

function compterPrets(batteries, seuil) {
  // Reprends ta fonction vérifiée.
  return 0;
}

function premierPret(batteries, seuil) {
  // Reprends ta recherche vérifiée.
  return -1;
}

function bilanFlotte(batteries, seuil) {
  const prets = 0;
  const premier = -1;
  return [batteries.length, prets, premier];
}

function bilanTemperatures(temperatures, minimum) {
  // Décompose le problème avec des fonctions nommées.
  // Renvoie [nombre de mesures, nombre d’alertes, premier indice].
  return [temperatures.length, 0, -1];
}

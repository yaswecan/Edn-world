function compterSousSeuil(batteries, seuil) {
  // Écris ton programme ici.
  return 0;
}

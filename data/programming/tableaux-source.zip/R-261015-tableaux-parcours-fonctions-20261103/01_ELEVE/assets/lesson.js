(function () {
'use strict';
const C=window.ARRAY_COURSE, R=window.ArrayLabRuntime, KEY='eden-tableaux-v1';
const $=(s,r=document)=>r.querySelector(s), $$=(s,r=document)=>Array.from(r.querySelectorAll(s));
const esc=v=>String(v===undefined?'undefined':v).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const fmt=v=>{if(v===undefined)return 'undefined';if(typeof v==='string')return v;try{return JSON.stringify(v);}catch{return '[valeur non sérialisable]';}};
const clone=v=>JSON.parse(JSON.stringify(v));
const names=['Je réactive','Je découvre et j’essaie','Je m’entraîne','Je réalise','Je retiens'];
let state={version:1,session:1,block:1,activity:null,work:{},quizzes:{},cloze:{},predictions:{},reduced:matchMedia('(prefers-reduced-motion: reduce)').matches};
let storageAvailable=true;
try{const saved=JSON.parse(localStorage.getItem(KEY)||'null');if(saved&&saved.version===1)state=restoreState(saved,false);}catch{storageAvailable=false;}
if(!C||!R){$('#content').textContent='Le cours ne peut pas démarrer. Décompresse toute l’archive et ouvre index.html avec ses fichiers assets.';return;}
let active=null,mode='code',traceResult=null,position=-1,playTimer=null,toastTimer=null,compareResult=null,comparePosition=-1,compareTimer=null;
function restoreState(incoming,merging){
 const record=v=>v&&typeof v==='object'&&!Array.isArray(v)?v:{};
 const data=record(incoming);
 const result={...state,version:1,session:[1,2].includes(data.session)?data.session:1,block:[1,2,3,4,5].includes(data.block)?data.block:1,activity:(C?.activities||[]).some(a=>a.id===data.activity)?data.activity:null,reduced:typeof data.reduced==='boolean'?data.reduced:state.reduced,work:merging?{...state.work}:{},quizzes:merging?{...state.quizzes}:{},predictions:merging?{...state.predictions}:{},cloze:merging?{...state.cloze}:{}};
 for(const a of C?.activities||[]){
  const w=record(record(data.work)[a.id]);
  if(typeof w.code==='string'&&w.code.length<=24000&&typeof w.args==='string'&&w.args.length<=6000)result.work[a.id]={code:w.code,args:w.args,reflection:typeof w.reflection==='string'?w.reflection.slice(0,6000):'',hints:Math.min(a.hints.length,Math.max(0,Number(w.hints)||0)),passed:merging?false:!!w.passed,visited:!!w.visited};
  const prediction=record(data.predictions)[a.id];
  if(Number.isInteger(prediction)&&a.prediction?.options[prediction])result.predictions[a.id]=prediction;
 }
 const allQuizzes=[...(C?.quizzes||[]),...(C?.quizzes||[]).filter(q=>['q2-for','q5-arguments'].includes(q.id)).map(q=>({...q,id:q.id+'-rappel-s2'}))];
 for(const q of allQuizzes){const answer=record(data.quizzes)[q.id];if(Number.isInteger(answer)&&q.options[answer])result.quizzes[q.id]=answer;}
 for(const cl of C?.cloze||[]){const answers=record(data.cloze)[cl.session];if(Array.isArray(answers))result.cloze[cl.session]=answers.slice(0,cl.segments.filter(x=>typeof x!=='string').length).map(v=>typeof v==='string'?v.slice(0,100):'');}
 return result;
}
function toast(message){const t=$('#toast');t.textContent=message;t.hidden=false;clearTimeout(toastTimer);toastTimer=setTimeout(()=>t.hidden=true,4200);}
function save(){state.session=Number(state.session)||1;try{localStorage.setItem(KEY,JSON.stringify(state));$('#save-state').textContent='Enregistré sur cet appareil';storageAvailable=true;}catch{$('#save-state').textContent='Pense à exporter ton travail';storageAvailable=false;}}
function stop(){clearInterval(playTimer);playTimer=null;const b=$('#play');if(b)b.textContent='Lire ▶';clearInterval(compareTimer);compareTimer=null;}
function work(a){if(!state.work[a.id])state.work[a.id]={code:a.starter,args:JSON.stringify(a.args),reflection:'',hints:0,passed:false};return state.work[a.id];}
function getActivities(){return C.activities.filter(a=>a.session===state.session&&a.block===state.block);}
function setPage(block,id){stop();state.block=block;state.activity=id||null;traceResult=null;position=-1;save();render();$('#main').focus({preventScroll:true});}
function heading(){const s=state.session;$('#page-heading').innerHTML=`<p class="eyebrow">SÉANCE ${s} / 2 · REPÈRE ${state.block} / 5</p><h1>${esc(names[state.block-1])}</h1><p class="lead">${esc([s===1?'Une liste de batteries. Un programme pour préparer la flotte.':'Retrouve tes repères, puis choisis comment parcourir la flotte.','Lis, prévois et observe ce que fait chaque ligne.','Change une chose. Compare ton résultat à ta prévision.','Construis une solution et vérifie-la sur plusieurs cas.','Retrouve les mots, prends des décisions et conserve ton travail.'][state.block-1])}</p>`;}
function render(){
 document.body.classList.toggle('reduced-motion',!!state.reduced);$('#reduce-motion').checked=!!state.reduced;$('#session').value=String(state.session);
 $('#steps').innerHTML=names.map((n,i)=>`<button class="nav-step" data-block="${i+1}" ${state.block===i+1?'aria-current="step"':''}><span class="n">0${i+1}</span><span>${n}</span></button>`).join('');
 $$('.nav-step').forEach(b=>b.addEventListener('click',()=>setPage(Number(b.dataset.block))));heading();
 if(state.block===1)renderStart();else if(state.block===5)renderSummary();else renderLab();
 if(!storageAvailable)$('#save-state').textContent='Pense à exporter ton travail';
}
function fleetHTML(values,current=-1){return `<div class="array-cells">${values.length?values.slice(0,16).map((v,i)=>`<div class="array-cell ${i===current?'current':''}" data-array-index="${i}"><span class="idx">indice ${i}</span><span class="val ${typeof v!=='number'?'text':''}">${esc(fmt(v))}</span><span class="value-caption">valeur</span>${typeof v==='number'&&v>=0&&v<=100?`<div class="battery" aria-hidden="true"><i style="width:${v}%"></i></div>`:''}</div>`).join(''):`<div class="empty-array">[] · aucun élément à parcourir</div>`}</div>${values.length>16?'<p class="small">Les 16 premières cases sont affichées.</p>':''}`;}
function renderStart(){
 const s=state.session;
 $('#content').innerHTML=`<div class="hero-grid"><section class="hero-copy"><span class="hero-pill">MISSION FLOTTE · ${s===1?'PARCOURIR ET COMPTER':'RECHERCHER ET DÉCOMPOSER'}</span><h2>${s===1?'Quels drones peuvent partir ?':'Trouver le bon drone. Réutiliser son code.'}</h2><p>${s===1?'La flotte possède quatre drones. Chaque nombre indique une batterie. Un drone est prêt à partir de 50 %, valeur incluse.':'Un parcours complet et une recherche du premier résultat ne répondent pas au même besoin. Tu vas comparer leurs étapes et assembler tes fonctions.'}</p><p>${s===1?'Ton programme doit compter les drones prêts, même quand la liste change.':'Le bilan final réunit trois informations : nombre total, nombre de drones prêts et indice du premier prêt.'}</p><button class="primary" id="start-lab">${s===1?'Observer la première case':'Reprendre avec une recherche'} →</button></section><section class="panel"><p class="eyebrow">DONNÉES DE DÉPART</p><div class="array-label"><code>batteries</code><span>length = 4</span></div>${fleetHTML([35,80,20,65])}<div class="dashboard"><div class="stat"><strong>4</strong><span>drones au total</span></div><div class="stat"><strong>2</strong><span>prêts à partir de 50 %</span></div><div class="stat"><strong>1</strong><span>indice du premier prêt</span></div></div><p class="small">L’indice 1 désigne le deuxième drone, dont la batterie vaut 80.</p></section></div><div class="note" style="margin-top:18px">${s===1?'Avant de coder : désigne une case, son indice et sa valeur. Les fonctions des premiers exemples sont fournies ; tu apprendras ensuite à les déclarer et à les appeler.':'Sans le cours : explique où commencent les indices, à quoi sert le compteur et ce qui fait avancer une boucle. Une difficulté ? Reprends le mémo avant la suite.'}</div><h2 style="margin-top:27px">Deux questions pour démarrer</h2><div id="start-quiz" class="quiz-grid"></div>`;
 $('#start-lab').onclick=()=>setPage(2);
 const questions=s===1?C.quizzes.filter(q=>q.session===1).slice(0,2):C.quizzes.filter(q=>['q2-for','q5-arguments'].includes(q.id)).map(q=>({...q,id:q.id+'-rappel-s2'}));
 renderQuizzes($('#start-quiz'),questions);
}
function renderQuizzes(container,questions){
 container.innerHTML=questions.map(q=>`<section class="quiz-card" data-quiz="${esc(q.id)}"><h3>${esc(q.question)}</h3>${q.code?`<pre class="quiz-code">${esc(q.code)}</pre>`:''}<div class="options">${q.options.map((o,i)=>`<button class="option" data-option="${i}">${esc(o.text)}</button>`).join('')}</div><div class="quiz-feedback" aria-live="polite"></div></section>`).join('');
 questions.forEach(q=>{const card=$(`[data-quiz="${q.id}"]`,container);const show=i=>{$$('.option',card).forEach((b,j)=>{b.classList.toggle('selected',i===j);b.classList.toggle('good',i===j&&i===q.correct);});$('.quiz-feedback',card).innerHTML=`<p class="feedback ${i===q.correct?'':'warn'}">${esc(q.options[i].feedback)}</p>`;};$$('.option',card).forEach(b=>b.onclick=()=>{const i=Number(b.dataset.option);state.quizzes[q.id]=i;save();show(i);});const prior=state.quizzes[q.id];if(Number.isInteger(prior)&&q.options[prior])show(prior);});
}
function renderLab(){
 const items=getActivities();active=items.find(a=>a.id===state.activity)||items[0];if(!active){$('#content').textContent='Aucun atelier dans ce repère.';return;}
 state.activity=active.id;const a=active,w=work(a);mode=(state.block===4||!a.demo)?'code':(w.visited?'code':'demo');w.visited=true;
 $('#content').innerHTML=`<div class="activity-picker">${items.map((x,i)=>`<button class="activity-chip ${x.id===a.id?'active':''}" data-activity="${x.id}">${x.transfer?'Reprise différée · ':''}${esc(x.title)}</button>`).join('')}</div><div class="activity-top"><div><h2>${esc(a.title)}</h2><p class="goal">${esc(a.goal)}</p></div><div class="mode-switch">${state.block!==4&&a.demo?'<button id="mode-demo">Voir l’exemple</button>':''}<button id="mode-code">Mon code</button></div></div>${a.transfer?'<p class="note">À reprendre lors d’une prochaine séance, sans correction sous les yeux. La règle change : une température égale au minimum ne déclenche pas d’alerte.</p>':''}<div class="explanation"><span class="micro-tag">LE REPÈRE</span><div>${a.explanation.map(t=>`<p>${esc(t)}</p>`).join('')}</div></div><div id="prediction-area"></div><details class="call-data"><summary class="small">Modifier les données de l’appel</summary><div class="inputs-row"><label for="call-args">Arguments de l’appel</label><input id="call-args" class="args-input" aria-label="Arguments au format tableau JSON" spellcheck="false"><button id="case-empty">Essayer une liste vide</button><button id="case-default">Données de départ</button></div></details><p id="call-caption" class="small"></p><div id="run-error" role="alert"></div><div class="workspace"><section class="visual-pane"><div class="pane-header"><strong>Ce que fait le programme</strong><small id="trace-kind">Avant l’exécution</small></div><div class="visual-body"><div class="array-label"><code id="array-name">Données de l’appel</code><span id="array-length"></span></div><div id="array-view"></div><p class="legend"><span class="index-color">Violet : indice</span><span class="value-color">Bleu : valeur</span><span>Orange : variable</span></p><div id="variables" class="variables"></div><div class="caption" id="trace-caption"><strong>À observer</strong>Prévois le résultat, puis avance pas à pas.</div><div id="mechanism"></div><div id="function-bindings"></div><div id="return-view"></div><div id="stack" class="stack"></div></div></section><section class="code-pane"><div class="pane-header"><strong id="editor-label">main.js</strong><small id="active-line-label">Code JavaScript</small></div><div class="editor-wrap"><pre class="line-numbers" aria-hidden="true"></pre><div class="active-line" aria-hidden="true"></div><textarea id="code" class="code-editor" aria-label="Éditeur de code JavaScript" spellcheck="false" wrap="off" autocapitalize="off" autocomplete="off" autocorrect="off"></textarea></div><div class="editor-footer"><button id="compile" class="primary">Exécuter</button><button id="reset-code">Reprendre le départ</button><button id="download-code">Exporter .js</button><small>Ctrl / ⌘ + Entrée</small></div></section></div><div class="runbar"><button id="restart" title="Revenir au début de la trace">↺ Début</button><button id="prev">← Précédent</button><button id="next">Pas suivant →</button><button id="play">Lire ▶</button><input id="trace-range" class="range" type="range" min="0" max="0" value="0" aria-label="Position dans la trace"><span id="trace-count" class="counter">0 / 0</span><label for="speed" class="small">Rythme</label><select id="speed"><option value="1100">Lent</option><option value="650" selected>Normal</option><option value="300">Rapide</option></select><button id="finish">Résultat</button></div><p class="run-info">La trace provient du code affiché et de tes arguments. Une étape correspond à une opération expliquée, pas à une mesure de vitesse du programme.</p><details class="console-panel"><summary>Console · ce qui a été affiché</summary><pre id="console-output" class="console-output">Aucun affichage pour le moment.</pre></details>${a.id==='a6-recherche-while'?'<section class="panel" style="margin-top:18px"><h3>Vérifier ma recherche</h3><div id="search-quiz" class="quiz-grid"></div></section>':''}<div class="practice-tools"><section class="panel"><h3>Un coup de pouce</h3><p>Commence par décrire ce que tu attendais et ce que tu observes.</p><div id="hints"></div><button id="hint-next" class="quiet">Afficher un indice</button></section><section class="panel"><h3>Vérifier mon programme</h3><ul>${a.checks.map(t=>`<li>${esc(t)}</li>`).join('')}</ul><button id="tests" class="primary">Tester plusieurs cas</button><div id="tests-output" class="test-list" aria-live="polite"></div></section></div>${state.session===2&&state.block===3?comparisonHTML():''}<div class="reflection"><label for="reflection">Ma trace : j’attendais… / j’ai observé… / j’ai corrigé…</label><textarea id="reflection" placeholder="Explique une décision ou une correction avec un exemple précis."></textarea></div><div class="next-row"><span class="fine">${a.transfer?'Garde cette production comme nouvelle preuve individuelle.':'Enregistre une explication, même si ton programme ne fonctionne pas encore.'}</span><button id="continue" class="primary">${items.slice(items.indexOf(a)+1).some(x=>!x.transfer)?'Atelier suivant':'Repère suivant'} →</button></div>`;
 $$('.activity-chip').forEach(b=>b.onclick=()=>setPage(state.block,b.dataset.activity));
 const e=$('#code');$('#call-args').value=w.args;$('#reflection').value=w.reflection;
 e.addEventListener('input',()=>{if(mode==='code'){w.code=e.value;w.passed=false;save();invalidate();lines();}});
 e.addEventListener('scroll',()=>{const n=$('.line-numbers');n.scrollTop=e.scrollTop;highlightLine();});
 e.addEventListener('keydown',event=>{if((event.ctrlKey||event.metaKey)&&event.key==='Enter'){event.preventDefault();compile();}else if(event.key==='Tab'&&!e.readOnly){event.preventDefault();let start=e.selectionStart,end=e.selectionEnd;e.setRangeText('  ',start,end,'end');e.dispatchEvent(new Event('input'));}});
 $('#call-args').oninput=()=>{w.args=$('#call-args').value;save();invalidate();updateCall();};
 $('#case-empty').onclick=()=>setArgs([[],...a.args.slice(1)]);$('#case-default').onclick=()=>setArgs(a.args);
 $('#mode-code').onclick=()=>setMode('code');if($('#mode-demo'))$('#mode-demo').onclick=()=>setMode('demo');
 $('#compile').onclick=compile;$('#restart').onclick=()=>{stop();if(ensureTrace()){position=0;showFrame();}};
 $('#prev').onclick=()=>{stop();if(ensureTrace()){position=Math.max(0,position-1);showFrame();}};
 $('#next').onclick=()=>{stop();if(ensureTrace()){position=Math.min(traceResult.trace.length-1,position+1);showFrame();}};
 $('#finish').onclick=()=>{stop();if(ensureTrace()){position=traceResult.trace.length-1;showFrame();}};
 $('#play').onclick=()=>{if(playTimer){stop();return;}if(!ensureTrace())return;if(position>=traceResult.trace.length-1)position=-1;$('#play').textContent='Pause ❚❚';playTimer=setInterval(()=>{position++;showFrame();if(position>=traceResult.trace.length-1)stop();},Number($('#speed').value));};
 $('#speed').onchange=()=>{if(playTimer){stop();$('#play').click();}};
 $('#trace-range').oninput=()=>{stop();position=Number($('#trace-range').value);showFrame();};
 $('#reset-code').onclick=()=>{if(mode==='demo'){setMode('code');return;}if(confirm('Reprendre le code de départ de cet atelier ? Exporte ton travail si tu veux conserver cette version.')){w.code=a.starter;w.passed=false;save();setMode('code');}};
 $('#download-code').onclick=()=>download(a.id+'.js',mode==='demo'?a.demo:w.code,'text/javascript');
 $('#hint-next').onclick=()=>{w.hints=Math.min(a.hints.length,w.hints+1);save();showHints();};
 $('#tests').onclick=runTests;$('#reflection').oninput=()=>{w.reflection=$('#reflection').value;save();};
 $('#continue').onclick=()=>{const next=items.slice(items.indexOf(a)+1).find(x=>!x.transfer);setPage(next?state.block:Math.min(5,state.block+1),next?.id);};
 setMode(mode);showHints();if($('#search-quiz'))renderQuizzes($('#search-quiz'),C.quizzes.filter(q=>['q7-while','q8-zero'].includes(q.id)));if($('#comparison'))wireComparison();
}
function setArgs(args){const w=work(active);w.args=JSON.stringify(args);$('#call-args').value=w.args;save();invalidate();updateCall();}
function setMode(m){stop();mode=m;$('#code').value=m==='demo'?active.demo:work(active).code;$('#code').readOnly=m==='demo';$('#editor-label').textContent=m==='demo'?'Exemple travaillé · lecture seule':'main.js · ton programme';$('#mode-code').classList.toggle('active',m==='code');if($('#mode-demo'))$('#mode-demo').classList.toggle('active',m==='demo');$('#tests').disabled=m==='demo';$('#reset-code').textContent=m==='demo'?'Passer à mon code':'Reprendre le départ';$('#tests-output').innerHTML='';invalidate();lines();updateCall();renderPrediction();}
function renderPrediction(){const p=active.prediction;if(mode!=='code'||!p){$('#prediction-area').innerHTML='';return;}$('#prediction-area').innerHTML=`<section class="prediction"><p class="eyebrow">AVANT DE CODER · QUESTION SUR LES DONNÉES INDIQUÉES</p><p class="question">${esc(p.question)}</p><div class="options">${p.options.map((o,i)=>`<button class="option" data-prediction="${i}">${esc(o.text)}</button>`).join('')}</div><p class="small">Modifier les données ou le code ne change pas cette question.</p><div id="prediction-feedback" aria-live="polite"></div></section>`;const show=i=>{$$('[data-prediction]').forEach((b,j)=>{b.classList.toggle('selected',i===j);b.classList.toggle('good',i===j&&i===p.correct);});$('#prediction-feedback').innerHTML=`<p class="feedback ${i===p.correct?'':'warn'}">${esc(p.options[i].feedback)}</p>`;};$$('[data-prediction]').forEach(b=>b.onclick=()=>{const i=Number(b.dataset.prediction);state.predictions[active.id]=i;save();show(i);});const prior=state.predictions[active.id];if(Number.isInteger(prior)&&p.options[prior])show(prior);}
function readArgs(){const raw=$('#call-args').value;if(raw.length>6000)throw new Error('Utilise une petite liste pour observer le parcours.');let args;try{args=JSON.parse(raw);}catch{throw new Error('Écris les arguments entre crochets : par exemple [[35,80,20,65],50].');}if(!Array.isArray(args))throw new Error('Les arguments doivent être réunis dans un tableau JSON.');if(args.some(x=>Array.isArray(x)&&x.length>60))throw new Error('Limite la liste à 60 valeurs pour ce laboratoire.');return args;}
function updateCall(){let args;try{args=readArgs();$('#call-caption').innerHTML=`Appel testé : <code>${esc(active.invoke)}(${esc(args.map(fmt).join(', '))})</code>`;}catch{$('#call-caption').textContent='Vérifie l’écriture des arguments avant l’exécution.';return;}if(!traceResult){const arr=Array.isArray(args[0])?args[0]:[];$('#array-view').innerHTML=fleetHTML(arr);$('#array-length').textContent='length = '+arr.length;}}
function invalidate(){
 stop();traceResult=null;position=-1;
 $('#trace-range').max=0;$('#trace-range').value=0;$('#trace-range').disabled=true;
 $('#trace-count').textContent='0 / 0';$('#prev').disabled=true;$('#next').disabled=false;$('#restart').disabled=false;$('#finish').disabled=false;$('#play').disabled=false;
 $('#run-error').innerHTML='';$('#variables').innerHTML='';$('#function-bindings').innerHTML='';$('#return-view').innerHTML='';$('#mechanism').innerHTML='';$('#stack').textContent='';
 $('#array-name').textContent='Données de l’appel';$('#trace-kind').textContent='Avant l’exécution';$('#trace-caption').innerHTML='<strong>À observer</strong>Prévois le résultat, puis avance pas à pas.';
 $('#console-output').textContent='Aucun affichage pour le moment.';$('#tests-output').innerHTML='';
 highlightLine();updateCall();
}
function lines(){const n=$('#code').value.split('\n').length;$('.line-numbers').textContent=Array.from({length:n},(_,i)=>i+1).join('\n');}
function highlightLine(){const e=$('#code'),bar=$('.active-line');if(!bar)return;const frame=traceResult?.trace[position];if(!frame||!frame.line){bar.style.display='none';$('#active-line-label').textContent='Code JavaScript';return;}bar.style.display='block';bar.style.top=(14+(frame.line-1)*23-e.scrollTop)+'px';$('#active-line-label').textContent='Ligne '+frame.line;}
function ensureTrace(){if(traceResult)return traceResult.trace.length>0;return compile(false);}
function compile(first=true){
 invalidate();let args;
 try{
  args=readArgs();
  if($('#code').value.length>24000)throw new Error('Le programme est trop long pour ce petit laboratoire.');
  traceResult=R.run($('#code').value,{invoke:active.invoke,args:clone(args),maxSteps:1800,maxTrace:1100});
 }catch(e){$('#run-error').innerHTML=`<div class="error">${esc(e.message)}</div>`;return false;}
 const notices=[];
 if(traceResult.error)notices.push(`<div class="error">${esc(typeof traceResult.error==='string'?traceResult.error:JSON.stringify(traceResult.error))}<br>Observe la trace, puis corrige une seule cause à la fois.</div>`);
 if(traceResult.traceTruncated)notices.push('<p class="feedback warn">La trace est abrégée : certains événements intermédiaires ne sont pas conservés. Réduis les données ou vérifie la condition d’arrêt.</p>');
 if(traceResult.logsTruncated)notices.push('<p class="feedback warn">La collecte des affichages a atteint sa limite. La console présente les premiers messages conservés.</p>');
 $('#run-error').innerHTML=notices.join('');
 position=first?0:-1;$('#trace-range').max=Math.max(0,traceResult.trace.length-1);$('#trace-range').disabled=!traceResult.trace.length;
 if(first)showFrame();return traceResult.trace.length>0;
}
function frameContext(at){
 const frames=traceResult?.trace||[];let loops=[];
 const signature=frame=>(frame.stack||[]).map(x=>x.name+'@'+x.line);
 const prefix=(a,b)=>a.length<=b.length&&a.every((x,i)=>x===b[i]);
 for(let i=0;i<=at&&i<frames.length;i++){
  const frame=frames[i],stack=signature(frame);
  loops=loops.filter(loop=>prefix(loop.stack,stack));
  if(frame.kind==='condition'&&['for','while'].includes(frame.context)){
   const key=frame.context+':'+frame.line+':'+stack.join('/');
   const present=loops.findIndex(loop=>loop.key===key);
   if(present>=0)loops=loops.slice(0,present+1);
   else loops.push({key,type:frame.context,line:frame.line,stack,index:null});
  }
  if(frame.kind==='foreach-start')loops.push({key:'forEach:'+frame.line+':'+stack.join('/'),type:'foreach',line:frame.line,stack,index:null,array:frame.array});
  if(frame.kind==='foreach-item'){
   const loop=[...loops].reverse().find(x=>x.type==='foreach'&&x.stack.length===stack.length);
   if(loop){loop.index=frame.index;loop.array=frame.array;loop.callbackName=null;}
  }
  if(frame.kind==='call'){
   const loop=[...loops].reverse().find(x=>x.type==='foreach'&&x.stack.length+1===stack.length);
   if(loop)loop.callbackName=frame.functionName;
  }
  if(frame.kind==='loop-end'){
   const type=frame.context==='forEach'?'foreach':frame.context;
   let pos=-1;for(let j=loops.length-1;j>=0;j--)if(loops[j].type===type&&loops[j].stack.length===stack.length){pos=j;break;}
   if(pos>=0)loops=loops.slice(0,pos);
  }
 }
 return {loop:loops[loops.length-1]||null,foreach:[...loops].reverse().find(x=>x.type==='foreach')||null};
}
function loopHeaders(code){
 const masked=code.replace(/\/\*[\s\S]*?\*\/|\/\/[^\n]*|"(?:\\.|[^"\\])*"|'(?:\\.|[^'\\])*'/g,text=>text.replace(/[^\n]/g,' '));
 const headers=[],pattern=/\b(for|while)\s*\(/g;let match;
 const lineAt=index=>masked.slice(0,index).split('\n').length;
 while((match=pattern.exec(masked))){
  const open=masked.indexOf('(',match.index);let depth=1,braces=0,brackets=0,end=open+1;const semicolons=[];
  for(;end<masked.length&&depth;end++){
   const ch=masked[end];if(ch==='(')depth++;else if(ch===')')depth--;else if(ch==='{')braces++;else if(ch==='}')braces--;else if(ch==='[')brackets++;else if(ch===']')brackets--;
   if(ch===';'&&depth===1&&!braces&&!brackets)semicolons.push(end);
  }
  if(depth)continue;
  const close=end-1,updateStart=semicolons.length===2?semicolons[1]+1:close;
  const conditionStart=semicolons.length===2?semicolons[0]+1:open+1,conditionEnd=semicolons.length===2?semicolons[1]:close;
  const lineEnd=masked.indexOf('\n',close),after=masked.slice(close+1,lineEnd<0?masked.length:lineEnd).trim();
  headers.push({type:match[1],line:lineAt(match.index),endLine:lineAt(close),updateLine:lineAt(updateStart),update:masked.slice(updateStart,close),condition:masked.slice(conditionStart,conditionEnd),init:semicolons.length===2?masked.slice(open+1,semicolons[0]):'',inlineBody:after!==''&&after!=='{'});
 }
 return headers;
}
function actualMechanism(frame,context){
 const foreach=context.foreach,depth=(frame.stack||[]).length;
 const callbackFrame=foreach&&depth===foreach.stack.length+1;
 const callbackResume=foreach&&frame.kind==='resume'&&frame.functionName===foreach.callbackName;
 if(callbackFrame||callbackResume||frame.kind.startsWith('foreach-'))return {type:'foreach',loop:foreach};
 if(['define','call','return','resume','done'].includes(frame.kind))return {type:'function',loop:null};
 if(frame.kind==='loop-end')return {type:frame.context==='forEach'?'foreach':frame.context,loop:null};
 if(frame.kind==='condition'&&['for','while'].includes(frame.context))return {type:frame.context,loop:context.loop};
 if(context.loop)return {type:context.loop.type,loop:context.loop};
 if(frame.kind==='declare'){
  const following=traceResult.trace.slice(position+1).find(next=>['condition','call','return','resume','foreach-start'].includes(next.kind));
  if(following?.kind==='condition'&&['for','while'].includes(following.context)){
   const header=loopHeaders($('#code').value).find(h=>h.type===following.context&&following.line>=h.line&&following.line<=h.endLine);
   if(header&&(header.type==='while'||new RegExp('(^|\\W)'+frame.name.replace(/[.*+?^$`{}()|[\]\\]/g,'\\$&')+'(\\W|$)').test(header.init)))return {type:header.type,loop:{type:header.type,line:following.line,initializing:true}};
  }
 }
 return {type:active.diagramType==='array'?'array':'function',loop:null};
}
function showFrame(){
 if(!traceResult||position<0)return;
 position=Math.min(position,traceResult.trace.length-1);const f=traceResult.trace[position],previous=traceResult.trace[position-1];if(!f)return;
 let args=[];try{args=readArgs();}catch{}
 const vars=f.variables||{},context=frameContext(position),known=['batteries','temperatures','liste','stocks'];
 let arrName=known.find(n=>Array.isArray(vars[n])),arr=arrName?vars[arrName]:(Array.isArray(args[0])?args[0]:[]);
 if(!arrName&&['resume','done'].includes(f.kind)){
  const lastSource=traceResult.trace.slice(0,position+1).reverse().find(frame=>(frame.stack||[]).length===1&&frame.stack[0].name===active.invoke&&known.some(name=>Array.isArray(frame.variables?.[name])));
  if(lastSource){arrName=known.find(name=>Array.isArray(lastSource.variables[name]));arr=lastSource.variables[arrName];}
 }
 if(Array.isArray(f.array)&&f.arrayName){arr=f.array;arrName=f.arrayName;}
 else if(Array.isArray(f.array)&&['foreach-start','foreach-item'].includes(f.kind)){arr=f.array;arrName=known.find(n=>Array.isArray(vars[n])&&JSON.stringify(vars[n])===JSON.stringify(arr))||arrName;}
 // The callback's parameter may have a misleading name: its iteration index
 // comes from the interpreter's forEach event, never from that name.
 const loop=context.loop;let index=Number.isInteger(f.index)?f.index:-1;
 if(index<0&&loop?.type==='foreach'&&Number.isInteger(loop.index))index=loop.index;
 else if(index<0&&loop&&['for','while'].includes(loop.type))index=Number.isInteger(vars.i)?vars.i:Number.isInteger(vars.indice)?vars.indice:Number.isInteger(vars.index)?vars.index:-1;
 $('#array-name').textContent=arrName||'Données de l’appel';$('#array-length').textContent='length = '+arr.length;$('#array-view').innerHTML=fleetHTML(arr,index);
 const entries=Object.entries(vars).filter(([k,v])=>typeof v!=='string'||!v.startsWith('[fonction')).filter(([k,v])=>!Array.isArray(v)&&typeof v!=='object').slice(-9);
 $('#variables').innerHTML=entries.map(([k,v])=>`<div class="variable ${previous&&JSON.stringify(previous.variables?.[k])!==JSON.stringify(v)?'changed':''}"><span>${esc(k)}</span><strong>${esc(fmt(v))}</strong></div>`).join('');
 const arrays=Object.entries(vars).filter(([k,v])=>Array.isArray(v)&&k!==arrName&&['copie','journal','retenus','resultats'].includes(k));
 if(arrays.length)$('#variables').innerHTML+=arrays.map(([k,v])=>`<div class="variable"><span>${esc(k)}</span><strong>${esc(fmt(v))}</strong></div>`).join('');
 if(!entries.length&&!arrays.length&&['done','resume'].includes(f.kind)&&!(f.stack||[]).length)$('#variables').innerHTML='<p class="small">L’appel est terminé : ses variables locales ne sont plus accessibles. La valeur renvoyée reste visible ci-dessous.</p>';
 $('#trace-kind').textContent=kindName(f.kind);$('#trace-caption').innerHTML=`<strong>${esc(kindName(f.kind))}</strong>${esc(f.label)}`;
 renderMechanism(f,context);
 const stack=f.stack||[],call=stack[stack.length-1],bindingData=f.kind==='call'?f:call?{params:call.params,args:call.args,functionName:call.name}:null;
 if(bindingData&&bindingData.params?.length)$('#function-bindings').innerHTML=`<p class="small" style="margin:12px 0 6px">Arguments de l’appel → paramètres de <code>${esc(bindingData.functionName)}</code></p><div class="bindings ${f.kind==='call'?'incoming':''}">${bindingData.params.map((p,i)=>`<div class="binding"><div>${esc(fmt(bindingData.args?.[i]))}</div><span aria-hidden="true">→</span><div>${esc(p)}</div></div>`).join('')}</div>`;
 else $('#function-bindings').innerHTML='';
 $('#stack').textContent=stack.length?'Appels en cours : '+stack.map(s=>s.name).join(' → '):'Aucun appel en cours.';
 const isReturn=['return','resume','done'].includes(f.kind);
 $('#return-view').innerHTML=isReturn?`<div class="result-box">${f.kind==='done'?'Résultat final de l’appel':f.kind==='return'?'Valeur renvoyée par cette fonction':'Valeur reçue par l’appelant'}<code>${esc(fmt(f.value))}</code></div>`:'';
 let displayed=traceResult.trace.slice(0,position+1).filter(t=>t.kind==='output');
 if(traceResult.logsTruncated)displayed=displayed.slice(0,traceResult.logs.length);
 $('#console-output').textContent=displayed.length?displayed.map(t=>Array.isArray(t.output)?t.output.map(fmt).join(' '):t.label).join('\n'):'Aucun affichage pour le moment.';
 $('#trace-count').textContent=(position+1)+' / '+traceResult.trace.length;$('#trace-range').value=position;
 const e=$('#code'),lineTop=14+Math.max(0,f.line-1)*23;if(lineTop<e.scrollTop||lineTop>e.scrollTop+e.clientHeight-45)e.scrollTop=Math.max(0,lineTop-80);$('.line-numbers').scrollTop=e.scrollTop;highlightLine();
 $('#prev').disabled=position<=0;$('#next').disabled=position>=traceResult.trace.length-1;
}
function kindName(kind){return ({define:'Déclaration',declare:'Initialisation',read:'Lecture d’une case',condition:'Condition',assign:'Affectation',update:'Mise à jour',call:'Appel de fonction',return:'Retour de fonction',resume:'Reprise de l’appelant','foreach-start':'Début du parcours','foreach-item':'Élément suivant','foreach-next':'Retour au parcours',output:'Affichage','loop-end':'Fin de boucle',done:'Terminé',error:'Arrêt de l’exécution'})[kind]||'Étape du programme';}
function renderMechanism(f,context){
 const mechanism=actualMechanism(f,context||frameContext(position)),type=mechanism.type,loop=mechanism.loop;
 let labels,notes,chosen=-1;
 if(type==='for'||type==='while'){
  labels=['Départ','Condition','Corps','Évolution'];notes=['une fois','avant chaque tour','si vrai',type==='for'?'dans l’en-tête':'à prévoir dans le code'];
  const header=loopHeaders($('#code').value).find(h=>h.type===type&&loop&&loop.line>=h.line&&loop.line<=h.endLine);
  if(loop?.initializing)chosen=0;
  else if(f.kind==='condition'&&f.context===type)chosen=1;
  else if(['declare','read','assign','update','output','expression'].includes(f.kind)){
   chosen=2;
   if(['assign','update'].includes(f.kind)&&header&&f.name){
    const namePattern=new RegExp('(^|\\W)'+f.name.replace(/[.*+?^$`{}()|[\]\\]/g,'\\$&')+'(\\W|$)');
    if(type==='while'&&namePattern.test(header.condition))chosen=3;
    if(type==='for'&&namePattern.test(header.update)&&f.line>=header.updateLine&&f.line<=header.endLine)chosen=header.inlineBody?-1:3;
   }
  }
 }else if(type==='foreach'){
  labels=['Élément','Callback','Retour','Suivant'];notes=['valeur et indice','une invocation','vers forEach','le parcours continue'];
  chosen=f.kind==='foreach-item'?0:f.kind==='return'?2:f.kind==='foreach-next'?3:['call','read','assign','update','output','declare','condition'].includes(f.kind)?1:-1;
 }else if(type==='function'){
  labels=['Déclaration','Appel','Instructions','Retour'];notes=['définit la tâche','arguments → paramètres','variables locales','vers l’appelant'];
  chosen=f.kind==='define'?0:f.kind==='call'?1:['return','resume'].includes(f.kind)?3:2;
 }else{$('#mechanism').innerHTML='';return;}
 if(['done','loop-end','error'].includes(f.kind))chosen=-1;
 const note=type==='foreach'?'Un return quitte le callback courant ; forEach peut appeler le suivant.':type==='for'?'La condition est testée avant chaque tour. L’évolution de l’en-tête, si elle existe, s’exécute après le corps.':type==='while'?'La condition est testée avant chaque tour. Le code doit prévoir ce qui la fait évoluer.':'Définir une fonction n’exécute pas son corps. Un appel fournit les arguments.';
 $('#mechanism').innerHTML=`<div class="flow" aria-label="Étapes du mécanisme">${labels.map((l,i)=>`<div class="flow-node ${chosen===i?'active':''}">${l}<small>${notes[i]}</small></div>`).join('')}</div><p class="flow-note">${note}</p>`;
}
function showHints(){const w=work(active);$('#hints').innerHTML=active.hints.slice(0,w.hints).map((h,i)=>`<p class="hint">${i+1}. ${esc(h)}</p>`).join('');$('#hint-next').disabled=w.hints>=active.hints.length;}
function runTests(){stop();const a=active,w=work(a);let passed=0;const results=a.tests.map(test=>{let r;try{r=R.run(w.code,{invoke:a.invoke,args:clone(test.args),maxSteps:3000,maxTrace:10});}catch(e){r={error:e.message};}let ok=false;try{ok=!r.error&&JSON.stringify(r.result)===JSON.stringify(test.expected);}catch{r.error='Le résultat contient une référence circulaire ou une valeur non comparable. Renvoie le résultat demandé par la consigne.';}if(ok)passed++;return {test,r,ok};});w.passed=passed===results.length;w.lastTests={passed,total:results.length};save();$('#tests-output').innerHTML=`<p class="small">${passed} / ${results.length} cas vérifiés. ${passed===results.length?'Explique maintenant pourquoi ta solution fonctionne.':'Commence par le premier cas qui échoue.'}</p>`+results.map(({test,r,ok})=>`<div class="test-row ${ok?'pass':'fail'}"><strong>${ok?'✓':'À reprendre'} · ${esc(test.label)}</strong><span>Appel : ${esc(a.invoke)}(${esc(test.args.map(fmt).join(', '))})</span><span>Attendu : ${esc(fmt(test.expected))} · Obtenu : ${esc(r.error||fmt(r.result))}</span></div>`).join('');}
function renderSummary(){const s=state.session,cl=C.cloze.find(x=>x.session===s);let blank=0;const values=state.cloze[s]||[];
 $('#content').innerHTML=`<section class="panel"><p class="eyebrow">JE RETROUVE LES MOTS</p><h2>Mon bilan à compléter</h2><p class="small">Fais un premier essai de mémoire. Tu peux ensuite afficher les mots disponibles.</p><div class="cloze">${cl.segments.map(seg=>typeof seg==='string'?esc(seg):`<input data-blank="${blank}" aria-label="Mot à compléter ${++blank}" value="${esc(values[blank-1]||'')}" autocomplete="off" spellcheck="false">`).join('')}</div><div id="word-bank" class="word-bank" hidden>${cl.bank.map(w=>`<span>${esc(w)}</span>`).join('')}</div><div class="cloze-actions"><button id="check-cloze" class="primary">Vérifier mes mots</button><button id="show-bank">Afficher les mots disponibles</button></div><div id="cloze-feedback" aria-live="polite"></div></section><h2 style="margin-top:27px">Trois décisions à expliquer</h2><div id="end-quiz" class="quiz-grid"></div><details class="panel" style="margin-top:18px"><summary>Une question supplémentaire pour aller plus loin</summary><div id="extra-quiz" class="quiz-grid"></div></details><div class="note" style="margin-top:20px">${s===1?'À la prochaine séance : retrouve les étapes du for et la différence entre paramètre et argument avant de rouvrir le mémo.':'Pour vérifier ce qui reste acquis : reprends plus tard le défi « Serre », avec de nouvelles données et une règle différente.'}</div><div class="summary-actions"><button id="summary-export" class="primary">Exporter mon travail</button><button id="summary-next">${s===1?'Passer à la séance 2':'Ouvrir le transfert différé'} →</button></div><p class="small">Les réponses aux QCM et aux textes à trous complètent ton programme. Le professeur observe aussi ta démarche, ton explication et l’aide utilisée.</p>`;
 $$('[data-blank]').forEach(input=>input.oninput=()=>{state.cloze[s]=$$('[data-blank]').map(x=>x.value);input.classList.remove('valid','invalid');save();});
 $('#show-bank').onclick=()=>{$('#word-bank').hidden=!$('#word-bank').hidden;$('#show-bank').textContent=$('#word-bank').hidden?'Afficher les mots disponibles':'Masquer les mots';};
 $('#check-cloze').onclick=()=>{const normalize=t=>t.trim().normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase();const blanks=cl.segments.filter(x=>typeof x!=='string');let ok=0;$$('[data-blank]').forEach((input,i)=>{const good=[blanks[i].answer,...(blanks[i].alternatives||[])].some(a=>normalize(a)===normalize(input.value));input.classList.toggle('valid',good);input.classList.toggle('invalid',!good);if(good)ok++;});$('#cloze-feedback').innerHTML=`<p class="feedback ${ok===blanks.length?'':'warn'}">${ok} / ${blanks.length} mots retrouvés. ${ok===blanks.length?esc(cl.explanation):'Reprends les champs soulignés en orange. Les mots disponibles peuvent te donner un indice.'}</p>`;};
 const qs=C.quizzes.filter(q=>q.session===s);renderQuizzes($('#end-quiz'),qs.slice(2,5));renderQuizzes($('#extra-quiz'),qs.slice(5));$('#summary-export').onclick=exportWork;$('#summary-next').onclick=()=>{if(s===1){state.session=2;setPage(1);}else setPage(4,'a10-transfert');};
}
function comparisonHTML(){return `<details class="panel comparison" id="comparison"><summary>Comparer for, while et forEach sur les mêmes données</summary><p>Les trois programmes ci-dessous comptent les batteries à partir de 50 %. Choisis une écriture, puis suis ses lectures et ses changements de compteur.</p><div class="comparison-buttons"><button data-compare="for" class="active">for</button><button data-compare="while">while</button><button data-compare="forEach">forEach</button></div><pre id="compare-code"></pre><div id="compare-array" class="compare-vis"></div><div class="comparison-run"><button id="compare-step">Étape suivante</button><button id="compare-reset">Recommencer</button><span id="compare-caption"></span></div><p id="compare-rule" class="small"></p><table><thead><tr><th>Écriture</th><th>Qui organise le parcours ?</th><th>Pour s’arrêter avant la fin</th></tr></thead><tbody><tr><td>for</td><td>Tu écris le départ, le test et l’évolution.</td><td>Condition, break ou return de la fonction.</td></tr><tr><td>while</td><td>Tu écris le test ; l’évolution doit être prévue.</td><td>Condition, break ou return de la fonction.</td></tr><tr><td>forEach</td><td>La méthode appelle ton callback pour les éléments présents.</td><td>Un return du callback ne termine pas le parcours. Choisis une autre écriture si nécessaire.</td></tr></tbody></table></details>`;}
function wireComparison(){const programs={for:'function compter(batteries, seuil) {\n  let nombre = 0;\n  for (let i = 0; i < batteries.length; i++) {\n    if (batteries[i] >= seuil) { nombre++; }\n  }\n  return nombre;\n}',while:'function compter(batteries, seuil) {\n  let nombre = 0;\n  let i = 0;\n  while (i < batteries.length) {\n    if (batteries[i] >= seuil) { nombre++; }\n    i++;\n  }\n  return nombre;\n}',forEach:'function compter(batteries, seuil) {\n  let nombre = 0;\n  batteries.forEach(function(batterie, indice) {\n    if (batterie >= seuil) { nombre++; }\n  });\n  return nombre;\n}'};let selected='for';const build=()=>{$('#compare-code').textContent=programs[selected];compareResult=R.run(programs[selected],{invoke:'compter',args:[[35,80,20,65],50]});comparePosition=-1;$('#compare-step').disabled=false;$('#compare-caption').textContent='Prêt à parcourir.';$('#compare-array').innerHTML=[35,80,20,65].map((v,i)=>`<div class="compare-item" data-compare-index="${i}">${v}</div>`).join('');$('#compare-rule').textContent=selected==='forEach'?'Le callback reçoit la valeur puis l’indice. forEach renvoie undefined ; la fonction compter renvoie nombre.':selected==='while'?'L’incrémentation est écrite dans le corps. Son oubli peut empêcher la boucle de terminer.':'L’incrémentation est écrite dans l’en-tête et se fait après le corps.';};$$('[data-compare]').forEach(b=>b.onclick=()=>{selected=b.dataset.compare;$$('[data-compare]').forEach(x=>x.classList.toggle('active',x===b));build();});$('#compare-step').onclick=()=>{comparePosition=Math.min(compareResult.trace.length-1,comparePosition+1);const f=compareResult.trace[comparePosition];const recentItem=compareResult.trace.slice(0,comparePosition+1).reverse().find(t=>t.kind==='foreach-item');const idx=Number.isInteger(f.index)?f.index:selected==='forEach'?recentItem?.index:f.variables?.i;$$('[data-compare-index]').forEach(x=>x.classList.toggle('active',Number(x.dataset.compareIndex)===idx));$('#compare-caption').textContent=f.label+(typeof f.variables?.nombre==='number'?' · nombre = '+f.variables.nombre:'');$('#compare-step').disabled=comparePosition>=compareResult.trace.length-1;};$('#compare-reset').onclick=build;build();}
function download(name,content,type){const url=URL.createObjectURL(new Blob([content],{type}));const a=document.createElement('a');a.href=url;a.download=name;document.body.appendChild(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),1000);}
function exportWork(){save();download('mission-flotte-mon-travail.json',JSON.stringify({format:'eden-tableaux-work-v1',exportedAt:new Date().toISOString(),state},null,2),'application/json');toast('Ton travail a été exporté. Conserve le fichier pour le reprendre ou le remettre.');}
$('#export-work').onclick=exportWork;$('#import-work').onclick=()=>$('#file-work').click();$('#file-work').onchange=async event=>{const f=event.target.files[0];if(!f)return;if(f.size>2000000){toast('Ce fichier est trop volumineux.');return;}try{const data=JSON.parse(await f.text());if(data.format!=='eden-tableaux-work-v1'||!data.state?.work)throw new Error('Format inconnu');const next=data.state;if(![1,2].includes(next.session)||![1,2,3,4,5].includes(next.block))throw new Error('Parcours inconnu');state=restoreState(next,true);traceResult=null;position=-1;stop();save();render();toast('Ton travail est repris. Relance les tests pour vérifier le programme.');}catch{toast('Le fichier ne correspond pas à un export de cet atelier.');}event.target.value='';};
$('#session').onchange=()=>{state.session=Number($('#session').value);setPage(1);};$('.brand').onclick=event=>{event.preventDefault();setPage(1);};$('#reduce-motion').onchange=()=>{state.reduced=$('#reduce-motion').checked;document.body.classList.toggle('reduced-motion',state.reduced);save();};
$('#memo-body').innerHTML=`<h3>Indice, valeur et taille</h3><p>Dans <code>[35,80,20,65]</code>, les indices vont de 0 à 3. <code>batteries[1]</code> vaut 80 ; <code>batteries.length</code> vaut 4. Le dernier indice d’un tableau non vide vaut <code>length - 1</code>.</p><h3>Un parcours for</h3><pre>for (let i = 0; i &lt; batteries.length; i++) {\n  console.log(batteries[i]);\n}</pre><p>Initialisation une fois → condition → corps si vrai → évolution → nouveau test. Le compteur des éléments retenus est distinct de l’indice qui parcourt les cases.</p><h3>Déclaration, paramètres et arguments</h3><pre>function estPret(batterie, seuil) {\n  return batterie &gt;= seuil;\n}\nconst resultat = estPret(80, 50);</pre><p><code>batterie</code> et <code>seuil</code> sont les paramètres. Dans cet appel, 80 et 50 sont les arguments. <code>return</code> transmet la valeur <code>true</code> à l’appelant. <code>console.log</code> sert à afficher.</p><h3>Choisir le parcours</h3><table><tr><th>for</th><td>Départ, condition et évolution réunis dans l’en-tête.</td></tr><tr><th>while</th><td>Répéter tant que la condition est vraie ; prévoir ce qui la fait évoluer.</td></tr><tr><th>forEach</th><td>Appeler une fonction pour les éléments présents du tableau. Son callback reçoit valeur, indice, tableau. Un return quitte ce callback, pas le parcours.</td></tr></table><h3>Trois tests utiles</h3><p>Liste vide ; valeur exactement à la limite ; résultat trouvé au premier ou au dernier indice, ou absent. Pour une recherche d’indice, 0 est un résultat valide et -1 peut signaler l’absence selon le contrat choisi.</p><h3>Décomposer</h3><p>Une fonction compte. Une autre recherche. Une troisième appelle les deux et réunit leurs résultats. Chaque fonction doit fonctionner avec d’autres arguments.</p><p><a href="memo-visuel.pdf" target="_blank" rel="noopener">Ouvrir le mémo visuel en PDF</a></p>`;
$('#open-memo').onclick=()=>$('#memo-dialog').showModal();$('#close-memo').onclick=()=>$('#memo-dialog').close();
document.addEventListener('visibilitychange',()=>{if(document.hidden)stop();});window.addEventListener('beforeunload',save);
render();
})();

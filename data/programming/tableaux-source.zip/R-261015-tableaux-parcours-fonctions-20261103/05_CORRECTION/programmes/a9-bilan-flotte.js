function compterPrets(batteries, seuil) {
  let nombre = 0;
  for (let i = 0; i < batteries.length; i++) {
    if (batteries[i] >= seuil) {
      nombre++;
    }
  }
  return nombre;
}

function premierPret(batteries, seuil) {
  let i = 0;
  while (i < batteries.length) {
    if (batteries[i] >= seuil) {
      return i;
    }
    i++;
  }
  return -1;
}

function bilanFlotte(batteries, seuil) {
  const prets = compterPrets(batteries, seuil);
  const premier = premierPret(batteries, seuil);
  return [batteries.length, prets, premier];
}

function journalBatteries(batteries) {
  const journal = [];
  batteries.forEach(function(batterie, indice) {
    journal.push("Drone " + indice + " : " + batterie + "%");
  });
  return journal;
}

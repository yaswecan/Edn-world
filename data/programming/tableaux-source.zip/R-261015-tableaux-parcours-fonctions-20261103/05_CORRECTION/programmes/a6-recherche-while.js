function premierPret(batteries, seuil) {
  let i = 0;
  while (i < batteries.length) {
    if (batteries[i] >= seuil) {
      return i;
    }
    i++;
  }
  return -1;
}

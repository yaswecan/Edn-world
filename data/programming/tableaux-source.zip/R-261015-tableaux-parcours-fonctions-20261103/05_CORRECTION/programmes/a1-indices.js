function tailleEtValeur(batteries, indice) {
  return [batteries.length, batteries[indice]];
}

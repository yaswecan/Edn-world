function premierPret(batteries, seuil) {
  for (let i = 0; i < batteries.length; i++) {
    if (batteries[i] >= seuil) {
      return i;
    }
  }
  return -1;
}

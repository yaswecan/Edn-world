function compterAlertes(temperatures, minimum) {
  let nombre = 0;
  for (let i = 0; i < temperatures.length; i++) {
    if (temperatures[i] < minimum) {
      nombre++;
    }
  }
  return nombre;
}

function premiereAlerte(temperatures, minimum) {
  let i = 0;
  while (i < temperatures.length) {
    if (temperatures[i] < minimum) {
      return i;
    }
    i++;
  }
  return -1;
}

function bilanTemperatures(temperatures, minimum) {
  const nombre = compterAlertes(temperatures, minimum);
  const premier = premiereAlerte(temperatures, minimum);
  return [temperatures.length, nombre, premier];
}

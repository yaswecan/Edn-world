function parcourir(batteries) {
  const copie = [];
  for (let i = 0; i < batteries.length; i++) {
    copie.push(batteries[i]);
  }
  return copie;
}
